import {Component, Inject, OnInit} from "@angular/core";
import {MAT_DIALOG_DATA, MatDialogModule, MatDialogRef} from "@angular/material/dialog";
import {MatButtonModule} from "@angular/material/button";
import {MatFormFieldModule} from "@angular/material/form-field";
import {MatIconModule} from "@angular/material/icon";
import {MatInputModule} from "@angular/material/input";
import {FormBuilder, FormGroup, ReactiveFormsModule, Validators} from "@angular/forms";
import {NgForOf, NgIf} from "@angular/common";
import {HomeService} from "../../../shared/service/home.service";
import {MatSnackBar, MatSnackBarModule} from "@angular/material/snack-bar";
import {MatDatepickerModule} from "@angular/material/datepicker";
import {MatNativeDateModule} from "@angular/material/core";
import {MatSelectModule} from "@angular/material/select";

@Component({
  selector: 'customer-dialog',
  templateUrl: 'customerPopup.html',
  standalone: true,
  imports: [
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    ReactiveFormsModule,
    NgIf,
    MatSnackBarModule,
    MatNativeDateModule,
    MatDatepickerModule,
    MatSelectModule,
    NgForOf
  ],
  providers: [
    MatNativeDateModule,
    MatDatepickerModule
  ]
})
export class CustomerDialog implements OnInit{
  form: any;
  constructor(
    public dialogRef: MatDialogRef<CustomerDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public fb: FormBuilder,
    public homeService:HomeService,
    private _snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.form=this.fb.group({
      customer_name:[this.data?.customer_name, Validators.required]
    });
  }

  save() {
    if (this.form.valid){
      if (this.data.customer_id!=undefined){
        console.log('put customr')
        this.homeService.putCustomer(this.form.value, this.data.customer_id).subscribe(response=>{
          this._snackBar.open('Customer is saved', 'Close', {duration: 2000})
          this.dialogRef.close();
        }, error => {
          this._snackBar.open('Something went wrong!', 'Close', {duration: 2000})
        });
      }else{
        this.homeService.postCustomer(this.form.value).subscribe(response=>{
          this._snackBar.open('Customer is saved', 'Close', {duration: 2000})
          this.dialogRef.close();
        }, error => {
          this._snackBar.open('Something went wrong!', 'Close', {duration: 2000})
        });
      }
    }
  }
}
