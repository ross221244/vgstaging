import {Component, ViewChild} from '@angular/core';
import {MatTableDataSource} from "@angular/material/table";
import {MatPaginator} from "@angular/material/paginator";
import {HomeService} from "../../shared/service/home.service";
import {MatDialog} from "@angular/material/dialog";
import {CustomerDialog} from "./popup/customerPopup";
import {MatSnackBar} from "@angular/material/snack-bar";

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss']
})
export class CustomerComponent {

  public customers=new MatTableDataSource<any>();
  public tableMeta=[
    {title:  'ID', key: 'customer_id'},
    {title:  'Customer name', key: 'customer_name'}
  ]
  public displayedColumn:string[]=[];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(private homeService: HomeService,
              public dialog: MatDialog,
              private _snackBar: MatSnackBar) {
  }
  ngOnInit(): void {
    this.displayedColumn=[];
    this.tableMeta.forEach(meta=>{
      this.displayedColumn.push(meta.key);
    });
    this.displayedColumn.push('action')
    this.homeService.getCustomers().subscribe(res=>{
      this.customers=new MatTableDataSource<any>(res);
      this.customers.paginator=this.paginator;

    }, error => {
      this.customers=new MatTableDataSource<any>([]);
    });
  }
  openDialog(data={}): void {
    const dialogRef = this.dialog.open(CustomerDialog, {
      width: '600px',
      data: data,
    });

    dialogRef.afterClosed().subscribe(result => {
      this.ngOnInit();
    });
  }

  deleteEntry(element:any) {
    if (confirm('You are going to delete '+element.customer_name)){
      this.homeService.deleteCustomer(element.customer_id).subscribe(res=>{
        this._snackBar.open('Customer is deleted', 'Close', {duration: 2000});
        this.ngOnInit();
      })
    }
  }
}
