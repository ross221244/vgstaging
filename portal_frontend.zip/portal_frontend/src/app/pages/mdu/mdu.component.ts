import { Component } from '@angular/core';
import {HomeService} from "../../shared/service/home.service";
import {MatDialog} from "@angular/material/dialog";
import {DialogOverviewExampleDialog} from "../event/popup/eventPopup";
import {MduDialog} from "./popup/mduPopup";
import {MatSnackBar} from "@angular/material/snack-bar";

@Component({
  selector: 'app-mdu',
  templateUrl: './mdu.component.html',
  styleUrls: ['./mdu.component.scss']
})
export class MduComponent {
  public mdu=[];
  public tableMeta=[
    {title:  'Serial number', key: 'serial_number'},
    {title:  'Build date', key: 'build_date'},
    {title:  'MDU name ', key: 'mdu_name'},
    {title:  'Build notes ', key: 'build_notes'},
  ]
  public displayedColumn:string[]=[];
  constructor(private homeService: HomeService,
              public dialog: MatDialog,
              private _snackBar: MatSnackBar) {
  }
  ngOnInit(): void {
    this.displayedColumn=[];
    this.tableMeta.forEach(meta=>{
      this.displayedColumn.push(meta.key);
    });
    this.displayedColumn.push('action')
    this.homeService.getAllMdu().subscribe(res=>{
      this.mdu=res;
    }, error => {
      this.mdu=[];
    });
  }
  openDialog(data={}): void {
    const dialogRef = this.dialog.open(MduDialog, {
      width: '600px',
      data: data,
    });

    dialogRef.afterClosed().subscribe(result => {
      this.ngOnInit();
    });
  }
  deleteEntry(element:any) {
    if (confirm('You are going to delete '+element.mdu_name)){
      this.homeService.deleteMDU(element.id).subscribe(res=>{
        this._snackBar.open('MDU is deleted', 'Close', {duration: 2000});
        this.ngOnInit();
      })
    }
  }
}
