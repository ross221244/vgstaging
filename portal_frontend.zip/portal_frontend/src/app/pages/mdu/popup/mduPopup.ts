import {Component, Inject, OnInit} from "@angular/core";
import {MAT_DIALOG_DATA, MatDialogModule, MatDialogRef} from "@angular/material/dialog";
import {MatButtonModule} from "@angular/material/button";
import {MatFormFieldModule} from "@angular/material/form-field";
import {MatIconModule} from "@angular/material/icon";
import {MatInputModule} from "@angular/material/input";
import {FormBuilder, FormGroup, ReactiveFormsModule, Validators} from "@angular/forms";
import {NgForOf, NgIf} from "@angular/common";
import {HomeService} from "../../../shared/service/home.service";
import {MatSnackBar, MatSnackBarModule} from "@angular/material/snack-bar";
import {MatDatepickerModule} from "@angular/material/datepicker";
import {MatNativeDateModule} from "@angular/material/core";
import {MatSelectModule} from "@angular/material/select";

@Component({
  selector: 'dialog-overview-example-dialog',
  templateUrl: 'mduPopup.html',
  standalone: true,
  imports: [
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    ReactiveFormsModule,
    NgIf,
    MatSnackBarModule,
    MatNativeDateModule,
    MatDatepickerModule,
    MatSelectModule,
    NgForOf
  ],
  providers: [
    MatNativeDateModule,
    MatDatepickerModule
  ]
})
export class MduDialog implements OnInit{
  form: any;
  bars:any[]=[];
  constructor(
    public dialogRef: MatDialogRef<MduDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public fb: FormBuilder,
    public homeService:HomeService,
    private _snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.form=this.fb.group({
      serial_number:[this.data?.serial_number, Validators.required],
      build_date:[this.data?.build_date, Validators.required],
      mdu_name:[this.data?.mdu_name, Validators.required],
      build_notes:[this.data?.build_notes, Validators.required]
    });
    this.homeService.getBar().subscribe(resp=>{
      this.bars=resp;
    });
  }

  save() {
    if (this.form.valid){
      if (this.data.id!=undefined){
        this.homeService.putMdu(this.form.value, this.data.id).subscribe(response=>{
          this._snackBar.open('Mdu is saved', 'Close', {duration: 2000})
          this.dialogRef.close();
        }, error => {
          this._snackBar.open('Something went wrong!', 'Close', {duration: 2000})
        });
      }else{
        this.homeService.postMdu(this.form.value).subscribe(response=>{
          this._snackBar.open('Mdu is saved', 'Close', {duration: 2000})
          this.dialogRef.close();
        }, error => {
          this._snackBar.open('Something went wrong!', 'Close', {duration: 2000})
        });
      }
    }
  }
}
