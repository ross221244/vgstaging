import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {MduRoutingModule} from './mdu-routing.module';
import {MduComponent} from './mdu.component';
import {MatButtonModule} from "@angular/material/button";
import {MatIconModule} from "@angular/material/icon";
import {MatTableModule} from "@angular/material/table";
import {MatToolbarModule} from "@angular/material/toolbar";
import {MatDialogModule} from "@angular/material/dialog";
import {MatNativeDateModule} from "@angular/material/core";
import {MatDatepickerModule} from "@angular/material/datepicker";
import {MatSnackBarModule} from "@angular/material/snack-bar";


@NgModule({
  declarations: [
    MduComponent
  ],
  imports: [
    CommonModule,
    MduRoutingModule,
    MatButtonModule,
    MatIconModule,
    MatTableModule,
    MatToolbarModule,
    MatDialogModule,
    MatNativeDateModule,
    MatDatepickerModule,
    MatSnackBarModule
  ],
  providers: [
    MatNativeDateModule,
    MatDatepickerModule
  ]
})
export class MduModule {
}
