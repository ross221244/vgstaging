import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MduComponent } from './mdu.component';

describe('MduComponent', () => {
  let component: MduComponent;
  let fixture: ComponentFixture<MduComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MduComponent]
    });
    fixture = TestBed.createComponent(MduComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
