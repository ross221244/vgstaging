import {Component, OnInit, ViewChild} from '@angular/core';
import {HomeService} from "../../shared/service/home.service";
import {MatTableDataSource} from "@angular/material/table";
import {MatPaginator} from "@angular/material/paginator";
import {MatDialog} from "@angular/material/dialog";
import {DialogOverviewExampleDialog} from "../event/popup/eventPopup";
import {ProductDialog} from "./popup/productPopup";
import {MatSnackBar} from "@angular/material/snack-bar";

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss']
})
export class ProductComponent implements OnInit{

  public products=new MatTableDataSource<any>();
  public tableMeta=[
    {title:  'Name', key: 'product_name'},
    {title:  'Brand', key: 'product_brand'}
  ]
  public displayedColumn:string[]=[];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(private homeService: HomeService,
              public dialog: MatDialog,
              private _snackBar: MatSnackBar) {
  }
  ngOnInit(): void {
    this.displayedColumn=[];
    this.tableMeta.forEach(meta=>{
      this.displayedColumn.push(meta.key);
    });
    this.displayedColumn.push('action')
    this.homeService.getProduct().subscribe(res=>{
      this.products=new MatTableDataSource<any>(res);
      this.products.paginator=this.paginator;

    }, error => {
      this.products=new MatTableDataSource<any>([]);
    });
  }
  openDialog(data={}): void {
    const dialogRef = this.dialog.open(ProductDialog, {
      width: '600px',
      data: data,
    });

    dialogRef.afterClosed().subscribe(result => {
      this.ngOnInit();
    });
  }

  deleteEntry(element:any) {
    if (confirm('You are going to delete '+element.product_name)){
      this.homeService.deleteProduct(element.id).subscribe(res=>{
        this._snackBar.open('Product is deleted', 'Close', {duration: 2000});
        this.ngOnInit();
      })
    }
  }
}
