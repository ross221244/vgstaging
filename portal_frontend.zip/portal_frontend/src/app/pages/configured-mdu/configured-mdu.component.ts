import {Component, OnInit, ViewChild} from '@angular/core';
import {MatTableDataSource} from "@angular/material/table";
import {MatPaginator} from "@angular/material/paginator";
import {HomeService} from "../../shared/service/home.service";
import {MatDialog} from "@angular/material/dialog";
import {DialogOverviewExampleDialog} from "../event/popup/eventPopup";
import {ConfMduDialog} from "./popup/confMduPopup";
import {MatSnackBar} from "@angular/material/snack-bar";

@Component({
  selector: 'app-configured-mdu',
  templateUrl: './configured-mdu.component.html',
  styleUrls: ['./configured-mdu.component.scss']
})
export class ConfiguredMduComponent implements OnInit{

  public configuredMDU=new MatTableDataSource<any>();
  public tableMeta=[
    {title:  'Name', key: 'configured_mdu_name'},
    {title:  'Product source', key: 'product_source'},
    {title:  'Installer name ', key: 'installer_name'},
    {title:  'Volume per measure ml ', key: 'vol_per_measure_ml'},
  ]
  public displayedColumn:string[]=[];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(private homeService: HomeService,
              public dialog: MatDialog,
              private _snackBar: MatSnackBar) {
  }
  ngOnInit(): void {
    this.displayedColumn=[];
    this.tableMeta.forEach(meta=>{
      this.displayedColumn.push(meta.key);
    });
    this.displayedColumn.push('action')
    this.homeService.getConfMDU().subscribe(res=>{
      this.configuredMDU=new MatTableDataSource<any>(res);
      this.configuredMDU.paginator=this.paginator;

    }, error => {
      this.configuredMDU=new MatTableDataSource<any>([]);
    });
  }
  openDialog(data={}): void {
    const dialogRef = this.dialog.open(ConfMduDialog, {
      width: '600px',
      data: data,
    });

    dialogRef.afterClosed().subscribe(result => {
      this.ngOnInit();
    });
  }
  deleteEntry(element:any) {
    if (confirm('You are going to delete '+element.configured_mdu_name)){
      this.homeService.deleteConfiguredMDU(element.id).subscribe(res=>{
        this._snackBar.open('Configured MDU is deleted', 'Close', {duration: 2000});
        this.ngOnInit();
      })
    }
  }
}
