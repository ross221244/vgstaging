import {Component, Inject, OnInit} from "@angular/core";
import {MAT_DIALOG_DATA, MatDialogModule, MatDialogRef} from "@angular/material/dialog";
import {MatButtonModule} from "@angular/material/button";
import {MatFormFieldModule} from "@angular/material/form-field";
import {MatIconModule} from "@angular/material/icon";
import {MatInputModule} from "@angular/material/input";
import {FormBuilder, FormGroup, ReactiveFormsModule, Validators} from "@angular/forms";
import {NgForOf, NgIf} from "@angular/common";
import {HomeService} from "../../../shared/service/home.service";
import {MatSnackBar, MatSnackBarModule} from "@angular/material/snack-bar";
import {MatDatepickerModule} from "@angular/material/datepicker";
import {MatNativeDateModule} from "@angular/material/core";
import {MatSelectModule} from "@angular/material/select";

@Component({
  selector: 'configuredMDU-dialog',
  templateUrl: 'confMduPopup.html',
  standalone: true,
  imports: [
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    ReactiveFormsModule,
    NgIf,
    MatSnackBarModule,
    MatNativeDateModule,
    MatDatepickerModule,
    MatSelectModule,
    NgForOf
  ],
  providers: [
    MatNativeDateModule,
    MatDatepickerModule
  ]
})
export class ConfMduDialog implements OnInit{
  form: any;
  bars:any[]=[];
  mdu:any[]=[];
  products:any[]=[];
  constructor(
    public dialogRef: MatDialogRef<ConfMduDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public fb: FormBuilder,
    public homeService:HomeService,
    private _snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.form=this.fb.group({
      configured_mdu_name:[this.data?.configured_mdu_name, Validators.required],
      product_source:[this.data?.product_source, Validators.required],
      installer_name:[this.data?.installer_name, Validators.required],
      vol_per_measure_ml:[this.data?.vol_per_measure_ml, Validators.required],
      bar_id:[this.data?.bar_id, Validators.required],
      mdu_system_id:[this.data?.mdu_system_id, Validators.required],
      product_id:[this.data?.product_id, Validators.required],
    });
    this.homeService.getBar().subscribe(resp=>{
      this.bars=resp;
    });
    this.homeService.getAllMdu().subscribe(resp=>{
      this.mdu=resp;
    });
    this.homeService.getProduct().subscribe(resp=>{
      this.products=resp;
    });
  }

  save() {
    console.log(this.form.value);
    console.log(this.form.valid)
    if (this.form.valid){
      if (this.data.id!=undefined){
        this.homeService.putConfMDU(this.form.value, this.data.id).subscribe(response=>{
          this._snackBar.open('Configured MDU is saved', 'Close', {duration: 2000})
          this.dialogRef.close();
        }, error => {
          this._snackBar.open('Something went wrong!', 'Close', {duration: 2000})
        });
      }else{
        console.log(this.form.value)
        this.homeService.postConfMdu(this.form.value).subscribe(response=>{
          this._snackBar.open('Configured MDU is saved', 'Close', {duration: 2000})
          this.dialogRef.close();
        }, error => {
          this._snackBar.open('Something went wrong!', 'Close', {duration: 2000})
        });
      }
    }
  }
}
