import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {ConfiguredMduRoutingModule} from './configured-mdu-routing.module';
import {ConfiguredMduComponent} from './configured-mdu.component';
import {MatButtonModule} from "@angular/material/button";
import {MatIconModule} from "@angular/material/icon";
import {MatPaginatorModule} from "@angular/material/paginator";
import {MatTableModule} from "@angular/material/table";
import {MatToolbarModule} from "@angular/material/toolbar";
import {MatDialogModule} from "@angular/material/dialog";
import {MatSnackBarModule} from "@angular/material/snack-bar";


@NgModule({
  declarations: [
    ConfiguredMduComponent
  ],
  imports: [
    CommonModule,
    ConfiguredMduRoutingModule,
    MatButtonModule,
    MatIconModule,
    MatPaginatorModule,
    MatTableModule,
    MatToolbarModule,
    MatDialogModule,
    MatSnackBarModule
  ]
})
export class ConfiguredMduModule {
}
