import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ConfiguredMduComponent } from './configured-mdu.component';

const routes: Routes = [{ path: '', component: ConfiguredMduComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConfiguredMduRoutingModule { }
