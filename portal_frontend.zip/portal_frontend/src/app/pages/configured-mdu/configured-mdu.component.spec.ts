import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfiguredMduComponent } from './configured-mdu.component';

describe('ConfiguredMduComponent', () => {
  let component: ConfiguredMduComponent;
  let fixture: ComponentFixture<ConfiguredMduComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ConfiguredMduComponent]
    });
    fixture = TestBed.createComponent(ConfiguredMduComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
