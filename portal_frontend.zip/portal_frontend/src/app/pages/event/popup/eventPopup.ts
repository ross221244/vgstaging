import {Component, Inject, OnInit} from "@angular/core";
import {MAT_DIALOG_DATA, MatDialogModule, MatDialogRef} from "@angular/material/dialog";
import {MatButtonModule} from "@angular/material/button";
import {MatFormFieldModule} from "@angular/material/form-field";
import {MatIconModule} from "@angular/material/icon";
import {MatInputModule} from "@angular/material/input";
import {FormBuilder, FormGroup, ReactiveFormsModule, Validators} from "@angular/forms";
import {NgForOf, NgIf} from "@angular/common";
import {HomeService} from "../../../shared/service/home.service";
import {MatSnackBar, MatSnackBarModule} from "@angular/material/snack-bar";
import {MatDatepickerModule} from "@angular/material/datepicker";
import {MatNativeDateModule} from "@angular/material/core";
import {MatSelectModule} from "@angular/material/select";

@Component({
  selector: 'dialog-overview-example-dialog',
  templateUrl: 'eventPopup.html',
  standalone: true,
  imports: [
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    ReactiveFormsModule,
    NgIf,
    MatSnackBarModule,
    MatNativeDateModule,
    MatDatepickerModule,
    MatSelectModule,
    NgForOf
  ],
  providers: [
    MatNativeDateModule,
    MatDatepickerModule
  ]
})
export class DialogOverviewExampleDialog implements OnInit{
  form: any;
  customers:any[]=[];
  constructor(
    public dialogRef: MatDialogRef<DialogOverviewExampleDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public fb: FormBuilder,
    public homeService:HomeService,
    private _snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.form=this.fb.group({
      event_name:[this.data?.event_name, Validators.required],
      event_start_date:[this.data?.event_start_date, Validators.required],
      event_end_date:[this.data?.event_end_date, Validators.required],
      event_notes:[this.data?.event_notes, Validators.required],
      customer_id:[this.data?.customer_id, Validators.required],
    });
    this.homeService.getCustomers().subscribe(resp=>{
      this.customers=resp;
    });
  }

  save() {
    if (this.form.valid){
      if (this.data.id!=undefined){
        this.homeService.putEvent(this.form.value, this.data.id).subscribe(response=>{
          this._snackBar.open('Event is saved', 'Close', {duration: 2000})
          this.dialogRef.close();
        }, error => {
          this._snackBar.open('Something went wrong!', 'Close', {duration: 2000})
        });
      }else{
        this.homeService.postEvent(this.form.value).subscribe(response=>{
          this._snackBar.open('Event is saved', 'Close', {duration: 2000})
          this.dialogRef.close();
        }, error => {
          this._snackBar.open('Something went wrong!', 'Close', {duration: 2000})
        });
      }
    }
  }
}
