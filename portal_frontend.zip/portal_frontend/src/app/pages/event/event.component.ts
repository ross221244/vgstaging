import {Component, OnInit, ViewChild} from '@angular/core';
import {HomeService} from "../../shared/service/home.service";
import {MatDialog} from "@angular/material/dialog";
import {DialogOverviewExampleDialog} from "./popup/eventPopup";
import {MatPaginator} from "@angular/material/paginator";
import {MatTableDataSource} from "@angular/material/table";
import {MatSnackBar} from "@angular/material/snack-bar";

@Component({
  selector: 'app-event',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.scss']
})
export class EventComponent implements OnInit{

  public customer=[];
  public events=new MatTableDataSource<any>();
  public tableMeta=[
    {title:  'Name', key: 'event_name'},
    {title:  'Start date', key: 'event_start_date'},
    {title:  'End date ', key: 'event_end_date'},
    {title:  'Note ', key: 'event_notes'},
  ]
  public displayedColumn:string[]=[];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(private homeService: HomeService,
              public dialog: MatDialog,
              private _snackBar: MatSnackBar) {
  }
  ngOnInit(): void {
    this.displayedColumn=[];
    this.tableMeta.forEach(meta=>{
      this.displayedColumn.push(meta.key);
    });
    this.displayedColumn.push('action')
    this.homeService.getEvent().subscribe(res=>{
      this.events=new MatTableDataSource<any>(res);
      this.events.paginator=this.paginator;

    }, error => {
      this.events=new MatTableDataSource<any>([]);
    });
  }
  openDialog(data={}): void {
    const dialogRef = this.dialog.open(DialogOverviewExampleDialog, {
      width: '600px',
      data: data,
    });

    dialogRef.afterClosed().subscribe(result => {
      this.ngOnInit();
    });
  }

  deleteEntry(element:any) {
    if (confirm('You are going to delete '+element.event_name)){
      this.homeService.deleteEvent(element.id).subscribe(res=>{
        this._snackBar.open('Event is deleted', 'Close', {duration: 2000});
        this.ngOnInit();
      })
    }
  }
}
