import {Component, OnInit, ViewChild} from '@angular/core';
import {HomeService} from "../../shared/service/home.service";
import {MatDialog} from "@angular/material/dialog";
import {BarDialog} from "./popup/barPopup";
import {MatTableDataSource} from "@angular/material/table";
import {MatPaginator} from "@angular/material/paginator";
import {MatSnackBar} from "@angular/material/snack-bar";

@Component({
  selector: 'app-bar',
  templateUrl: './bar.component.html',
  styleUrls: ['./bar.component.scss']
})
export class BarComponent implements OnInit{
  public bars=new MatTableDataSource<any>();
  public tableMeta=[
    {title:  'Name', key: 'bar_name'}
  ]
  public displayedColumn:string[]=[];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(private homeService: HomeService,
              public dialog: MatDialog,
              private _snackBar: MatSnackBar) {
  }
  ngOnInit(): void {
    this.displayedColumn=[];
    this.tableMeta.forEach(meta=>{
      this.displayedColumn.push(meta.key);
    });
    this.displayedColumn.push('action')
    this.homeService.getBar().subscribe(res=>{
      this.bars=new MatTableDataSource<any>(res);
      this.bars.paginator=this.paginator;
    }, error => {
      this.bars=new MatTableDataSource<any>([]);
      this.bars.paginator=this.paginator;
    });
  }
  openDialog(data={}): void {
    const dialogRef = this.dialog.open(BarDialog, {
      width: '600px',
      data: data,
    });

    dialogRef.afterClosed().subscribe(result => {
      this.ngOnInit();
    });
  }
  deleteEntry(element:any) {
    if (confirm('You are going to delete '+element.bar_name)){
      this.homeService.deleteBar(element.id).subscribe(res=>{
        this._snackBar.open('Bar is deleted', 'Close', {duration: 2000});
        this.ngOnInit();
      })
    }
  }
}
