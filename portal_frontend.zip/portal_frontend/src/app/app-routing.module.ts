import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {AuthComponent} from "./shared/layout/auth/auth.component";
import {BaseComponent} from "./shared/layout/base/base.component";

const routes: Routes = [
  { path: 'login', component: AuthComponent, loadChildren: () => import('./login/login.module').then(m => m.LoginModule) },
  { path: 'home', component: BaseComponent, loadChildren: () => import('./home/home.module').then(m => m.HomeModule) },
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'event', component: BaseComponent, loadChildren: () => import('./pages/event/event.module').then(m => m.EventModule) },
  { path: 'bar', component: BaseComponent, loadChildren: () => import('./pages/bar/bar.module').then(m => m.BarModule) },
  { path: 'product', component: BaseComponent, loadChildren: () => import('./pages/product/product.module').then(m => m.ProductModule) },
  { path: 'customer', component: BaseComponent, loadChildren: () => import('./pages/customer/customer.module').then(m => m.CustomerModule) },
  { path: 'mdu', component: BaseComponent, loadChildren: () => import('./pages/mdu/mdu.module').then(m => m.MduModule) },
  { path: 'configured_mdu', component: BaseComponent, loadChildren: () => import('./pages/configured-mdu/configured-mdu.module').then(m => m.ConfiguredMduModule) }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
