import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {LoginService} from "../shared/service/login.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit{
  hide=true;
  public form: any;
  public showErrorMsg='';
  showProgress=false;
  constructor(
    private fb: FormBuilder,
    private loginService: LoginService,
    private router: Router
  ) {

  }

  submigLogin() {
    if (this.form.valid){
      this.showErrorMsg='';
      this.showProgress=true;
      this.loginService.postLogin(this.form.value).subscribe(res=>{
        this.showProgress=false;
        localStorage.setItem('access_token', res.access)
        localStorage.setItem('refresh_token', res.refresh)
        return this.router.navigateByUrl('/home');
      }, error => {
        this.showProgress=false
        this.showErrorMsg='Invalid username or password'
      })
    }

  }

  ngOnInit(): void {
    this.form=this.fb.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required]]
    })
  }
}
