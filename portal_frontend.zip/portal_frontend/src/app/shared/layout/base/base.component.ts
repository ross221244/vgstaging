import {Component, OnInit} from '@angular/core';
import {Router} from "@angular/router";

@Component({
  selector: 'app-base',
  templateUrl: './base.component.html',
  styleUrls: ['./base.component.scss']
})
export class BaseComponent implements OnInit {
  constructor(private router: Router) {
  }

  ngOnInit(): void {
    if (this.router.url == '/home' || this.router.url == '/login') {

    } else {
      if (localStorage.getItem('access_token')) {
        let token = localStorage.getItem('access_token') || 'asdf';
        let userData = JSON.parse(atob(token.split('.')[1]));
        if (userData['vodoo_people'] == false) {
          this.router.navigateByUrl('/home')
        }
      } else {
        localStorage.clear();
        this.router.navigateByUrl('/login')
      }
    }
  }

}
