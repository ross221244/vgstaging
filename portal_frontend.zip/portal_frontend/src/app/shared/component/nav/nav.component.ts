import {Component, inject, OnInit} from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import {Router} from "@angular/router";

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.scss']
})
export class NavComponent implements OnInit{
  private breakpointObserver = inject(BreakpointObserver);
  public showButtons=false
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );
  constructor(private router:Router) {
  }

  ngOnInit(): void {
    if (localStorage.getItem('access_token')){
      let token=localStorage.getItem('access_token')||'asdf';
      let userData=JSON.parse(atob(token.split('.')[1]));
      this.showButtons=userData['vodoo_people']==true;
    }
  }

  logout() {
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
    this.router.navigateByUrl('/login')
  }
}
