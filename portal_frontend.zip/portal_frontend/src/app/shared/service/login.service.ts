import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private baseurl='https://rossedwards17-34da524f58a4.herokuapp.com';
  constructor(private httpClient: HttpClient) { }
  postLogin(data:any):Observable<any>{
    return this.httpClient.post(this.baseurl+'/auth/token/', data);
  }

  verityAuth(data:any): Observable<any> {
    return this.httpClient.post(this.baseurl+'/auth/token/verify/', data);
  }
}
