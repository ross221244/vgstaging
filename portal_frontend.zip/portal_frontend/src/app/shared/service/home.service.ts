import {Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class HomeService {
  private baseurl = 'https://rossedwards17-34da524f58a4.herokuapp.com';

  constructor(private httpClient: HttpClient) {
  }

  getEvent(): Observable<any> {
    return this.httpClient.get(this.baseurl + '/v1/api/event/');
  }

  getBars(eventId: number): Observable<any> {
    return this.httpClient.get(this.baseurl + `/v1/api/event/${eventId}/bars/`);
  }

  getMdu(barId: number): Observable<any> {
    return this.httpClient.get(this.baseurl + `/v1/api/bar/${barId}/configured_mdu/`)
  }

  getProducts(mduId: number): Observable<any> {
    return this.httpClient.get(this.baseurl + `/v1/api/configured_mdu/${mduId}/products/`);
  }

  getDispense(mduId: number): Observable<any> {
    return this.httpClient.get(this.baseurl + `/v1/api/configured_mdu/${mduId}/dispense_log/`);
  }


  postEvent(value: any): Observable<any> {
    return this.httpClient.post(this.baseurl + '/v1/api/event/', value);
  }

  putEvent(value: any, id: number): Observable<any> {
    return this.httpClient.put(this.baseurl + `/v1/api/event/${id}/`, value);
  }

  getCustomers(): Observable<any> {
    return this.httpClient.get(this.baseurl + `/v1/api/customer/`);
  }

  getBar(): Observable<any> {
    return this.httpClient.get(this.baseurl + '/v1/api/bar/');
  }

  putBar(value: any, id: number): Observable<any> {
    return this.httpClient.put(this.baseurl + `/v1/api/bar/${id}/`, value);
  }

  postBar(value: any): Observable<any> {
    return this.httpClient.post(this.baseurl + `/v1/api/bar/`, value);
  }

  getAllMdu():Observable<any> {
    return this.httpClient.get(this.baseurl + `/v1/api/mdu_system/`);
  }

  putMdu(value:any, id:number):Observable<any> {
    return this.httpClient.put(this.baseurl + `/v1/api/mdu_system/${id}/`, value);
  }
  postMdu(value:any):Observable<any> {
    return this.httpClient.post(this.baseurl + `/v1/api/mdu_system/`, value);
  }

  getProduct():Observable<any> {
    return this.httpClient.get(this.baseurl + `/v1/api/product/`);
  }

  putProduct(value:any, id:number):Observable<any> {
    return this.httpClient.put(this.baseurl + `/v1/api/product/${id}/`, value);
  }

  postProduct(value:any):Observable<any> {
    return this.httpClient.post(this.baseurl + `/v1/api/product/`, value);
  }

  putCustomer(value: any, customer_id: number):Observable<any> {
    return this.httpClient.put(this.baseurl + `/v1/api/customer/${customer_id}/`, value);
  }

  postCustomer(value: any):Observable<any> {
    return this.httpClient.post(this.baseurl + `/v1/api/customer/`, value);
  }

  putConfMDU(value: any, id: number): Observable<any> {
    return this.httpClient.put(this.baseurl + `/v1/api/configured_mdu/${id}/`, value);
  }

  postConfMdu(value: any):Observable<any> {
    return this.httpClient.post(this.baseurl + `/v1/api/configured_mdu/`, value);
  }

  getConfMDU():Observable<any> {
    return this.httpClient.get(this.baseurl + `/v1/api/configured_mdu/`);
  }

  deleteEvent(id:number):Observable<any> {
    return this.httpClient.delete(this.baseurl + `/v1/api/event/${id}/`);
  }

  deleteBar(id: number):Observable<any> {
    return this.httpClient.delete(this.baseurl + `/v1/api/bar/${id}/`)
  }

  deleteConfiguredMDU(id:number):Observable<any> {
    return this.httpClient.delete(this.baseurl + `/v1/api/configured_mdu/${id}/`);
  }

  deleteCustomer(id:number):Observable<any> {
    return this.httpClient.delete(this.baseurl + `/v1/api/customer/${id}/`);
  }

  deleteMDU(id:number):Observable<any> {
    return this.httpClient.delete(this.baseurl + `/v1/api/mdu_system/${id}/`);
  }

  deleteProduct(id:number):Observable<any> {
    return this.httpClient.delete(this.baseurl + `/v1/api/product/${id}/`);
  }
}
