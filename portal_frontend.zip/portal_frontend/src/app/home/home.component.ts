import {Component, OnInit} from '@angular/core';
import {HomeService} from "../shared/service/home.service";
import {LoginService} from "../shared/service/login.service";
import {Router} from "@angular/router";
import { Chart } from 'chart.js/auto'
import * as moment from 'moment';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  public chart: any;
  public events = [];
  public bars = [];
  public BarMdu: any = [];
  public products: any = [];
  public dispenseLog:any=[];
  showSpinnerForBar = false;
  showSpinnerForMdu = false;
  showSpinnerForProduct=false;
  showSpinnerForDispense=false;
  noBarFound = false;
  noMduFound = false;
  noProductFound = false;
  noDispenseFound = false;
  barsColumn = ['bar_name'];
  mduColumn = ['configured_mdu_name', 'installer_name', 'product_source'];
  productColumn = ['product_name', 'product_brand'];
  public selectedEventName = '';
  public selectedBarName = '';
  public selectedMduName = '';

  constructor(private homeService: HomeService,
              private router: Router,
              private loginService: LoginService) {
  }

  ngOnInit(): void {
    this.events = [];
    this.bars = [];
    this.BarMdu = [];
    this.loginService.verityAuth({token: localStorage.getItem('access_token')}).subscribe(r => {

      this.homeService.getEvent().subscribe(res => {
        this.events = res;
      })
    }, error => {
      localStorage.clear();
      this.router.navigateByUrl('/login')
    });
  }

  selectedEvent($event: any) {
    if (this.chart){
      this.chart.destroy();
    }
    this.bars = [];
    this.BarMdu = [];
    this.products=[];
    this.noBarFound = false;
    this.noMduFound = false;
    this.noDispenseFound=false;
    this.noProductFound=false
    this.selectedMduName='';
    this.selectedBarName='';
    this.selectedEventName = $event.event_name;
    this.showSpinnerForBar = true;
    if ($event.id != undefined) {
      this.homeService.getBars($event.id).subscribe(res => {
        this.showSpinnerForBar = false;
        this.bars = res;
        this.noBarFound = this.bars.length == 0
      });
    }
  }

  barSelected(row: any) {
    this.selectedBarName = row.bar_name;
    this.showSpinnerForMdu = true;
    this.noProductFound=false;
    this.noMduFound = false;
    this.noDispenseFound=false;
    if (this.chart){
      this.chart.destroy();
    }
    this.products=[];
    this.homeService.getMdu(row.id).subscribe(res => {
      this.showSpinnerForMdu = false;
      this.BarMdu = res;
      this.noMduFound = this.BarMdu.length == 0
    });
  }

  mduSelected(row: any) {
    if (this.chart){
      this.chart.destroy();
    }
    let dispenseLog:any=[];
    this.dispenseLog=[];
    this.selectedMduName = row.configured_mdu_name;
    this.showSpinnerForProduct = true;
    this.showSpinnerForDispense=true;
    this.noProductFound=false;
    this.noDispenseFound=false;
    this.homeService.getProducts(row.id).subscribe(res=>{
      this.showSpinnerForProduct=false;
      this.products=res;
      this.noProductFound=this.products.length==0
    }, error => {
      this.showSpinnerForProduct=false;

    });
    this.homeService.getDispense(row.id).subscribe(res=>{
      this.showSpinnerForDispense=false;
      dispenseLog=res;
      this.noDispenseFound=dispenseLog.length==0;
      if (dispenseLog.length){
        dispenseLog.forEach((data:any, index:number)=>{

          dispenseLog[index]['c']=(Number(data.odometer_end)-Number(data.odometer_start))*Number(row.vol_per_measure_ml);
        });
        this.createChart(dispenseLog)
      }
    })
  }

  createChart(data:any){
    this.dispenseLog=data;
    let labels:any[]=[];
    let dts:any[]=[];
    data.forEach((d:any)=>{
      labels.push(moment(new Date(d.dispense_time)).format('YYYY-MM-DD hh:mm A'));
      dts.push(d.c)
    })
    this.chart = new Chart("MyChart", {
      type: 'line', //this denotes tha type of chart

      data: {// values on X-Axis
        labels: labels,
        datasets: [
          {
            label: "Dispense",
            data: dts,
            backgroundColor: 'blue'
          }
        ]
      },
      options: {
      }

    });
  }
}
